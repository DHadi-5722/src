document.getElementById('confbtn').onclick = function() {
	document.getElementById('demo').innerHTML = 'Conference text goes here';
}